import { LightningElement, track} from 'lwc';
import  getPendingPayments from '@salesforce/apex/PaymentController.getPendingPayments';
import  markPaymentPaid from '@salesforce/apex/PaymentController.markPaymentPaid';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class PendingPaymentList extends LightningElement {
    @track pendingPayments = [];
    @track totalAmount = 0;
    @track isEmpty = true;

    connectedCallback() {
        this.fetchPendingPayments();
    }

    fetchPendingPayments() {
        getPendingPayments().then(result => {
            this.pendingPayments = result;
            this.calculateTotalAmount();
            this.isEmpty = this.pendingPayments.length === 0;
        });
    }

    calculateTotalAmount() {
        this.totalAmount = this.pendingPayments.reduce((sum, payment) => sum + payment.Amount__c, 0);
    }

    handleMarkPaid(event) {
        const paymentId = event.currentTarget.dataset.id;

        this.updatePaymentStatus(paymentId);
    }


    updatePaymentStatus(paymentId){
        markPaymentPaid({ paymentId }).then(() => {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Success',
                    message: 'Payment Paid successfully!',
                    variant: 'success'
                })
            );

            this.pendingPayments=this.pendingPayments.filter(pay => pay.Id !== paymentId);
            if(this.pendingPayments.length === 0){
                this.isEmpty = true;
            }
            this.calculateTotalAmount();
        })
        .catch(error => {
            console.log('Error marking payment as paid: ', error);
        });
    }
}